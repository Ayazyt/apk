package com.example.sleeptimer

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.SweepGradient
import android.util.AttributeSet
import android.view.View

/**
 * حلقه‌ی دایره‌ای برای نمایش پیشرفت تایمر، با یک ترک نازک در پس‌زمینه
 * و یک آرکِ گرادیانی (بنفش → فیروزه‌ای) که نسبت زمان باقی‌مانده را نشان می‌دهد.
 */
class TimerRingView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    private var progress: Float = 1f // 1f = زمان کامل، 0f = تمام‌شده

    private val trackPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 22f
        color = Color.parseColor("#1B2540")
        strokeCap = Paint.Cap.ROUND
    }

    private val progressPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 22f
        strokeCap = Paint.Cap.ROUND
        color = Color.parseColor("#4FD1C5")
    }

    private val rect = RectF()

    fun setProgress(value: Float) {
        progress = value.coerceIn(0f, 1f)
        invalidate()
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        val stroke = trackPaint.strokeWidth
        rect.set(stroke / 2, stroke / 2, w - stroke / 2, h - stroke / 2)
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        canvas.drawArc(rect, 0f, 360f, false, trackPaint)
        val sweep = 360f * progress
        canvas.save()
        canvas.rotate(-90f, width / 2f, height / 2f)
        canvas.drawArc(rect, 0f, sweep, false, progressPaint)
        canvas.restore()
    }
}
