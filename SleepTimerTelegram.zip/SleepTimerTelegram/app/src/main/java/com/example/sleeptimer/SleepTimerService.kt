package com.example.sleeptimer

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ComponentName
import android.content.Intent
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.media.MediaPlayer
import android.media.session.MediaSessionManager
import android.os.Build
import android.os.CountDownTimer
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import androidx.core.app.NotificationCompat

/**
 * این سرویس یک شمارش معکوس اجرا می‌کند.
 * وقتی زمان تمام شود، یک فایل صوتی کاملاً بی‌صدا را پخش می‌کند در حالی که
 * Audio Focus را به صورت انحصاری (AUDIOFOCUS_GAIN) نگه می‌دارد.
 * این کار باعث می‌شود اندروید به تمام برنامه‌های دیگر که در حال پخش صدا
 * هستند (از جمله تلگرام) سیگنال AUDIOFOCUS_LOSS بفرستد و آن‌ها پخش را
 * متوقف کنند. نگه‌داشتن فوکوس برای چند ثانیه (به‌جای رها کردن فوری) باعث
 * می‌شود برنامه‌ی مقصد فرصت کافی برای پردازش و توقف واقعی پخش داشته باشد.
 */
class SleepTimerService : Service() {

    private var countDownTimer: CountDownTimer? = null
    private lateinit var audioManager: AudioManager
    private var silentPlayer: MediaPlayer? = null
    private var focusRequest: AudioFocusRequest? = null
    private var savedVolume: Int = -1
    private var fadeOriginalVolume: Int = -1
    private val handler = Handler(Looper.getMainLooper())

    companion object {
        const val CHANNEL_ID = "sleep_timer_channel"
        const val NOTIFICATION_ID = 1
        const val EXTRA_MINUTES = "extra_minutes"
        const val ACTION_STOP = "action_stop_timer"
        const val ACTION_PAUSE_MUSIC = "action_pause_music"
        const val ACTION_TICK = "com.example.sleeptimer.TICK"
        const val EXTRA_REMAINING_MS = "extra_remaining_ms"

        // مدت زمانی که فوکوس صوتی نگه داشته می‌شود تا مطمئن شویم
        // برنامه‌ی مقصد واقعاً پخش را متوقف کرده است.
        private const val FOCUS_HOLD_MS = 4000L

        // مدت زمان محو تدریجی صدا پیش از قطع کامل (میلی‌ثانیه)
        private const val FADE_DURATION_MS = 20000L
    }

    override fun onCreate() {
        super.onCreate()
        audioManager = getSystemService(AUDIO_SERVICE) as AudioManager
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopTimerAndSelf()
            return START_NOT_STICKY
        }

        if (intent?.action == ACTION_PAUSE_MUSIC) {
            pauseViaMediaSessions()
            return START_NOT_STICKY
        }

        val minutes = intent?.getIntExtra(EXTRA_MINUTES, 30) ?: 30
        val millis = minutes * 60 * 1000L

        // اگر از قبل صدا میوت مانده بود (مثلاً تایمر قبلی تمام شده بود)،
        // موقع شروع یک تایمر جدید صدا را برمی‌گردانیم.
        unmuteIfNeeded()

        val finishAt = System.currentTimeMillis() + millis
        startForeground(NOTIFICATION_ID, buildNotification(finishAt, running = true))
        startCountdown(millis)

        return START_STICKY
    }

    private fun unmuteIfNeeded() {
        try {
            if (savedVolume >= 0) {
                audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, savedVolume, 0)
                savedVolume = -1
            }
        } catch (_: Exception) {
        }
    }

    private fun startCountdown(millis: Long) {
        countDownTimer?.cancel()
        fadeOriginalVolume = -1
        countDownTimer = object : CountDownTimer(millis, 1000) {
            override fun onTick(millisUntilFinished: Long) {
                // نوتیفیکیشن دیگر هر ثانیه بازسازی نمی‌شود؛ شمارش زنده‌ی آن
                // توسط خودِ سیستم اندروید (Chronometer) انجام می‌شود که هیچ‌گاه
                // دچار لگ یا عقب‌افتادگی نمی‌شود. اینجا فقط UI داخل اپ را به‌روز می‌کنیم.
                sendTick(millisUntilFinished)

                // در ثانیه‌های پایانی، صدا را به‌جای قطع ناگهانی، آرام‌آرام کم می‌کنیم.
                if (millisUntilFinished in 1..FADE_DURATION_MS) {
                    applyVolumeFade(millisUntilFinished)
                }
            }

            override fun onFinish() {
                pauseAllMediaPlayback()
                sendTick(0)
                updateNotificationFinished()
            }
        }.start()
    }

    private fun applyVolumeFade(millisUntilFinished: Long) {
        try {
            if (fadeOriginalVolume < 0) {
                fadeOriginalVolume = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC)
            }
            if (fadeOriginalVolume <= 0) return
            val fraction = millisUntilFinished.toFloat() / FADE_DURATION_MS.toFloat()
            val target = (fadeOriginalVolume * fraction).toInt().coerceIn(0, fadeOriginalVolume)
            audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, target, 0)
        } catch (_: Exception) {
        }
    }

    private fun pauseAllMediaPlayback() {
        // روش ۰ (بهترین و مستقیم‌ترین راه): اگر مجوز «دسترسی به اعلان‌ها» داده
        // شده باشد، مستقیماً به هر برنامه‌ای که در حال پخش است دستور Pause
        // می‌فرستیم. این روش واقعاً پخش را در خودِ برنامه (مثلاً تلگرام) متوقف
        // می‌کند، نه فقط صدا را قطع می‌کند.
        pauseViaMediaSessions()

        val attrs = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_MEDIA)
            .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
            .build()

        // روش ۱ (تلاش برای توقف واقعی): گرفتن فوکوس صوتی انحصاری تا
        // برنامه‌های دیگر سیگنال AUDIOFOCUS_LOSS دریافت کنند.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val request = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
                .setAudioAttributes(attrs)
                .setOnAudioFocusChangeListener { }
                .build()
            focusRequest = request
            audioManager.requestAudioFocus(request)
        } else {
            @Suppress("DEPRECATION")
            audioManager.requestAudioFocus(
                null,
                AudioManager.STREAM_MUSIC,
                AudioManager.AUDIOFOCUS_GAIN
            )
        }

        try {
            silentPlayer?.release()
            silentPlayer = MediaPlayer.create(this, R.raw.silence).apply {
                isLooping = true
                setAudioAttributes(attrs)
                start()
            }
        } catch (_: Exception) {
        }

        // روش ۲ (تضمینی و همیشه مؤثر): میوت مستقیم استریم موزیک در سطح سیستم،
        // به‌عنوان پشتیبان برای برنامه‌هایی که به MediaSession یا Audio Focus
        // پاسخ نمی‌دهند.
        try {
            savedVolume = if (fadeOriginalVolume >= 0) fadeOriginalVolume else audioManager.getStreamVolume(AudioManager.STREAM_MUSIC)
            fadeOriginalVolume = -1
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                audioManager.adjustStreamVolume(
                    AudioManager.STREAM_MUSIC,
                    AudioManager.ADJUST_MUTE,
                    0
                )
            } else {
                @Suppress("DEPRECATION")
                audioManager.setStreamMute(AudioManager.STREAM_MUSIC, true)
            }
        } catch (_: Exception) {
        }

        handler.postDelayed({
            releaseFocusAndStop()
        }, FOCUS_HOLD_MS)
    }

    /**
     * لیست تمام برنامه‌هایی که در حال حاضر یک MediaSession فعال دارند را
     * می‌گیرد (مثل تلگرام، اسپاتیفای، یوتیوب موزیک و ...) و به هرکدام دستور
     * Pause می‌فرستد. این تابع فقط در صورتی کار می‌کند که کاربر مجوز
     * «دسترسی به اعلان‌ها» را برای این اپ در تنظیمات گوشی فعال کرده باشد.
     */
    private fun pauseViaMediaSessions(): Boolean {
        return try {
            val manager = getSystemService(MEDIA_SESSION_SERVICE) as MediaSessionManager
            val componentName = ComponentName(this, NotificationAccessService::class.java)
            val controllers = manager.getActiveSessions(componentName)
            var handled = false
            for (controller in controllers) {
                try {
                    controller.transportControls.pause()
                    handled = true
                } catch (_: Exception) {
                    try {
                        controller.transportControls.stop()
                        handled = true
                    } catch (_: Exception) {
                    }
                }
            }
            handled
        } catch (_: SecurityException) {
            // مجوز «دسترسی به اعلان‌ها» هنوز فعال نشده است.
            false
        } catch (_: Exception) {
            false
        }
    }

    private fun releaseFocusAndStop() {
        silentPlayer?.let {
            try {
                if (it.isPlaying) it.stop()
                it.release()
            } catch (_: Exception) {
            }
        }
        silentPlayer = null

        focusRequest?.let {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                audioManager.abandonAudioFocusRequest(it)
            }
        }
        stopSelf()
    }

    private fun stopTimerAndSelf() {
        countDownTimer?.cancel()
        handler.removeCallbacksAndMessages(null)

        // اگر تایمر حین محو تدریجی صدا متوقف شد، صدا را به مقدار اصلی برمی‌گردانیم.
        try {
            if (fadeOriginalVolume >= 0) {
                audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, fadeOriginalVolume, 0)
                fadeOriginalVolume = -1
            }
        } catch (_: Exception) {
        }

        silentPlayer?.let {
            try {
                if (it.isPlaying) it.stop()
                it.release()
            } catch (_: Exception) {
            }
        }
        silentPlayer = null
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun sendTick(remainingMs: Long) {
        val tickIntent = Intent(ACTION_TICK).apply {
            putExtra(EXTRA_REMAINING_MS, remainingMs)
            setPackage(packageName)
        }
        sendBroadcast(tickIntent)
    }

    private fun formatTime(millis: Long): String {
        val totalSeconds = millis / 1000
        val m = totalSeconds / 60
        val s = totalSeconds % 60
        return String.format("%02d:%02d", m, s)
    }

    private fun buildNotification(finishAtMillis: Long, running: Boolean): android.app.Notification {
        val stopIntent = Intent(this, SleepTimerService::class.java).apply {
            action = ACTION_STOP
        }
        val stopPendingIntent = PendingIntent.getService(
            this, 0, stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val pauseMusicIntent = Intent(this, SleepTimerService::class.java).apply {
            action = ACTION_PAUSE_MUSIC
        }
        val pauseMusicPendingIntent = PendingIntent.getService(
            this, 1, pauseMusicIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        // با لمس نوتیفیکیشن، اپ باز می‌شود و پیش‌نمایش وضعیت تایمر را نشان می‌دهد.
        val openAppIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or
                Intent.FLAG_ACTIVITY_SINGLE_TOP
        }
        val contentPendingIntent = PendingIntent.getActivity(
            this, 0, openAppIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val builder = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Hush")
            .setContentText(if (running) "Music will be silenced when time is up" else "Music playback stopped")
            .setSmallIcon(R.drawable.ic_notification)
            .setColor(0xFF4FD1C5.toInt())
            .setOngoing(running)
            .setContentIntent(contentPendingIntent)
            .setOnlyAlertOnce(true)

        if (running) {
            // System Chronometer: Android itself handles the live countdown,
            // no manual per-second updates needed — never laggy or buggy.
            builder.setUsesChronometer(true)
            builder.setChronometerCountDown(true)
            builder.setWhen(finishAtMillis)
            builder.addAction(0, "Stop Music", pauseMusicPendingIntent)
            builder.addAction(0, "Stop Timer", stopPendingIntent)
        }

        return builder.build()
    }

    private fun updateNotificationFinished() {
        val manager = getSystemService(NotificationManager::class.java)
        manager.notify(NOTIFICATION_ID, buildNotification(System.currentTimeMillis(), running = false))
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Hush Timer",
                NotificationManager.IMPORTANCE_LOW
            )
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
    }

    override fun onDestroy() {
        countDownTimer?.cancel()
        handler.removeCallbacksAndMessages(null)
        silentPlayer?.release()
        silentPlayer = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
