package com.example.sleeptimer

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.media.MediaPlayer
import android.os.Build
import android.os.CountDownTimer
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import androidx.core.app.NotificationCompat

/**
 * این سرویس یک شمارش معکوس اجرا می‌کند.
 * وقتی زمان تمام شود، یک فایل صوتی کاملاً بی‌صدا را پخش می‌کند در حالی که
 * Audio Focus را به صورت انحصاری (AUDIOFOCUS_GAIN) نگه می‌دارد.
 * این کار باعث می‌شود اندروید به تمام برنامه‌های دیگر که در حال پخش صدا
 * هستند (از جمله تلگرام) سیگنال AUDIOFOCUS_LOSS بفرستد و آن‌ها پخش را
 * متوقف کنند. نگه‌داشتن فوکوس برای چند ثانیه (به‌جای رها کردن فوری) باعث
 * می‌شود برنامه‌ی مقصد فرصت کافی برای پردازش و توقف واقعی پخش داشته باشد.
 */
class SleepTimerService : Service() {

    private var countDownTimer: CountDownTimer? = null
    private lateinit var audioManager: AudioManager
    private var silentPlayer: MediaPlayer? = null
    private var focusRequest: AudioFocusRequest? = null
    private val handler = Handler(Looper.getMainLooper())

    companion object {
        const val CHANNEL_ID = "sleep_timer_channel"
        const val NOTIFICATION_ID = 1
        const val EXTRA_MINUTES = "extra_minutes"
        const val ACTION_STOP = "action_stop_timer"
        const val ACTION_TICK = "com.example.sleeptimer.TICK"
        const val EXTRA_REMAINING_MS = "extra_remaining_ms"

        // مدت زمانی که فوکوس صوتی نگه داشته می‌شود تا مطمئن شویم
        // برنامه‌ی مقصد واقعاً پخش را متوقف کرده است.
        private const val FOCUS_HOLD_MS = 4000L
    }

    override fun onCreate() {
        super.onCreate()
        audioManager = getSystemService(AUDIO_SERVICE) as AudioManager
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopTimerAndSelf()
            return START_NOT_STICKY
        }

        val minutes = intent?.getIntExtra(EXTRA_MINUTES, 30) ?: 30
        val millis = minutes * 60 * 1000L

        startForeground(NOTIFICATION_ID, buildNotification(formatTime(millis)))
        startCountdown(millis)

        return START_STICKY
    }

    private fun startCountdown(millis: Long) {
        countDownTimer?.cancel()
        countDownTimer = object : CountDownTimer(millis, 1000) {
            override fun onTick(millisUntilFinished: Long) {
                updateNotification(formatTime(millisUntilFinished))
                sendTick(millisUntilFinished)
            }

            override fun onFinish() {
                pauseAllMediaPlayback()
                sendTick(0)
            }
        }.start()
    }

    private fun pauseAllMediaPlayback() {
        val attrs = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_MEDIA)
            .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
            .build()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val request = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
                .setAudioAttributes(attrs)
                .setOnAudioFocusChangeListener { }
                .build()
            focusRequest = request
            audioManager.requestAudioFocus(request)
        } else {
            @Suppress("DEPRECATION")
            audioManager.requestAudioFocus(
                null,
                AudioManager.STREAM_MUSIC,
                AudioManager.AUDIOFOCUS_GAIN
            )
        }

        try {
            silentPlayer?.release()
            silentPlayer = MediaPlayer.create(this, R.raw.silence).apply {
                isLooping = true
                setAudioAttributes(attrs)
                start()
            }
        } catch (_: Exception) {
        }

        handler.postDelayed({
            releaseFocusAndStop()
        }, FOCUS_HOLD_MS)
    }

    private fun releaseFocusAndStop() {
        silentPlayer?.let {
            try {
                if (it.isPlaying) it.stop()
                it.release()
            } catch (_: Exception) {
            }
        }
        silentPlayer = null

        focusRequest?.let {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                audioManager.abandonAudioFocusRequest(it)
            }
        }
        stopSelf()
    }

    private fun stopTimerAndSelf() {
        countDownTimer?.cancel()
        handler.removeCallbacksAndMessages(null)
        silentPlayer?.let {
            try {
                if (it.isPlaying) it.stop()
                it.release()
            } catch (_: Exception) {
            }
        }
        silentPlayer = null
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun sendTick(remainingMs: Long) {
        val tickIntent = Intent(ACTION_TICK).apply {
            putExtra(EXTRA_REMAINING_MS, remainingMs)
            setPackage(packageName)
        }
        sendBroadcast(tickIntent)
    }

    private fun formatTime(millis: Long): String {
        val totalSeconds = millis / 1000
        val m = totalSeconds / 60
        val s = totalSeconds % 60
        return String.format("%02d:%02d", m, s)
    }

    private fun buildNotification(timeText: String): android.app.Notification {
        val stopIntent = Intent(this, SleepTimerService::class.java).apply {
            action = ACTION_STOP
        }
        val stopPendingIntent = PendingIntent.getService(
            this, 0, stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("تایمر خواب فعال است")
            .setContentText("زمان باقی‌مانده: $timeText")
            .setSmallIcon(R.drawable.ic_notification)
            .setColor(0xFF6C5CE7.toInt())
            .setOngoing(true)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "توقف", stopPendingIntent)
            .build()
    }

    private fun updateNotification(timeText: String) {
        val manager = getSystemService(NotificationManager::class.java)
        manager.notify(NOTIFICATION_ID, buildNotification(timeText))
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Sleep Timer",
                NotificationManager.IMPORTANCE_LOW
            )
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
    }

    override fun onDestroy() {
        countDownTimer?.cancel()
        handler.removeCallbacksAndMessages(null)
        silentPlayer?.release()
        silentPlayer = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
