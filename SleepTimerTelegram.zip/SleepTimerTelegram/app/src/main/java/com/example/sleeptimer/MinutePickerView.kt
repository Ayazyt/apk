package com.example.sleeptimer

import android.content.Context
import android.graphics.Typeface
import android.util.AttributeSet
import android.util.TypedValue
import android.view.Gravity
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.LinearSnapHelper
import androidx.recyclerview.widget.RecyclerView
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * چرخ عددی عمودی شبیه پیکر انتخاب زمان/تاریخ در iOS و MIUI:
 * عدد وسط بزرگ و پررنگ، اعداد اطراف هرچه دورتر کم‌رنگ‌تر و کوچک‌تر.
 */
class MinutePickerView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : RecyclerView(context, attrs) {

    companion object {
        private const val MIN_VALUE = 1
        private const val MAX_VALUE = 999
    }

    var onValueChanged: ((Int) -> Unit)? = null

    private val values = (MIN_VALUE..MAX_VALUE).toList()
    private var itemHeightPx = 0
    private var currentSelected = 30

    private val itemAdapter = object : Adapter<RowHolder>() {
        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RowHolder {
            val tv = TextView(context).apply {
                layoutParams = LayoutParams(LayoutParams.MATCH_PARENT, itemHeightPx)
                gravity = Gravity.CENTER
                setTextColor(0xFFFFFFFF.toInt())
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 20f)
            }
            return RowHolder(tv)
        }

        override fun onBindViewHolder(holder: RowHolder, position: Int) {
            holder.textView.text = values[position].toString()
        }

        override fun getItemCount(): Int = values.size
    }

    private inner class RowHolder(val textView: TextView) : ViewHolder(textView)

    init {
        itemHeightPx = (46 * resources.displayMetrics.density).toInt()
        layoutManager = LinearLayoutManager(context)
        adapter = itemAdapter
        clipToPadding = false
        setHasFixedSize(true)

        LinearSnapHelper().attachToRecyclerView(this)

        addOnScrollListener(object : OnScrollListener() {
            override fun onScrolled(recyclerView: RecyclerView, dx: Int, dy: Int) {
                applyFadeScaleEffect()
            }

            override fun onScrollStateChanged(recyclerView: RecyclerView, newState: Int) {
                if (newState == SCROLL_STATE_IDLE) {
                    val centerValue = findCenteredValue()
                    if (centerValue != null && centerValue != currentSelected) {
                        currentSelected = centerValue
                        onValueChanged?.invoke(currentSelected)
                    }
                }
            }
        })

        post {
            setPaddingRelative(0, itemHeightPx * 2, 0, itemHeightPx * 2)
            scrollToInitialPosition(currentSelected)
        }
    }

    private fun scrollToInitialPosition(value: Int) {
        val index = (value - MIN_VALUE).coerceIn(0, values.size - 1)
        (layoutManager as LinearLayoutManager).scrollToPositionWithOffset(index, 0)
        postDelayed({ applyFadeScaleEffect() }, 50)
    }

    fun setMinutes(value: Int) {
        currentSelected = value.coerceIn(MIN_VALUE, MAX_VALUE)
        scrollToInitialPosition(currentSelected)
    }

    fun getSelectedMinutes(): Int = currentSelected

    private fun applyFadeScaleEffect() {
        val centerY = height / 2f
        for (i in 0 until childCount) {
            val child = getChildAt(i) ?: continue
            val childCenter = (child.top + child.bottom) / 2f
            val distance = abs(childCenter - centerY)
            val maxDistance = itemHeightPx * 2.2f
            val fraction = 1f - min(1f, distance / maxDistance)
            val alpha = max(0.22f, fraction)
            val textSize = 15f + (9f * fraction) // 15sp دورترین تا 24sp وسط

            if (child is TextView) {
                child.alpha = alpha
                child.setTextSize(TypedValue.COMPLEX_UNIT_SP, textSize)
                child.setTypeface(null, if (fraction > 0.9f) Typeface.BOLD else Typeface.NORMAL)
            }
        }
    }

    private fun findCenteredValue(): Int? {
        val lm = layoutManager as? LinearLayoutManager ?: return null
        val centerY = height / 2f
        var closestPos = -1
        var closestDistance = Float.MAX_VALUE
        for (i in 0 until childCount) {
            val child = getChildAt(i) ?: continue
            val childCenter = (child.top + child.bottom) / 2f
            val distance = abs(childCenter - centerY)
            if (distance < closestDistance) {
                closestDistance = distance
                closestPos = lm.getPosition(child)
            }
        }
        if (closestPos == -1) return null
        return values.getOrNull(closestPos)
    }
}
