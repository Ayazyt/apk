package com.example.sleeptimer

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.util.AttributeSet
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.roundToInt
import kotlin.math.sin

/**
 * A rotary dial that doubles as:
 *  - a touch-driven minute selector (drag anywhere on the ring, starting from 1,
 *    one full clockwise turn = 60 minutes, extra laps go beyond that), and
 *  - a live countdown display once the timer is running (non-interactive).
 */
class RotaryDialView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    companion object {
        private const val LAP_MINUTES = 60
        private const val MIN_MINUTES = 1
        private const val MAX_MINUTES = 999
    }

    var minutes: Int = 30
        private set

    var onMinutesChanged: ((Int) -> Unit)? = null

    private var countdownMode = false
    private var countdownText: String = ""
    private var countdownProgress: Float = 1f

    private val trackPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 22f
        color = Color.parseColor("#1B2540")
        strokeCap = Paint.Cap.ROUND
    }
    private val progressPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 22f
        strokeCap = Paint.Cap.ROUND
        color = Color.parseColor("#4FD1C5")
    }
    private val thumbFillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = Color.parseColor("#4FD1C5")
    }
    private val thumbStrokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 6f
        color = Color.parseColor("#0A0E14")
    }
    private val numberPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textAlign = Paint.Align.CENTER
        typeface = Typeface.create("sans-serif-black", Typeface.NORMAL)
    }
    private val unitPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#7C8AA5")
        textAlign = Paint.Align.CENTER
        typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        letterSpacing = 0.14f
    }

    private val rect = RectF()
    private var cx = 0f
    private var cy = 0f
    private var radius = 0f

    private var cumulativeDegrees = 0.0
    private var lastAngle: Double? = null

    init {
        cumulativeDegrees = ((minutes - MIN_MINUTES).toDouble() / LAP_MINUTES) * 360.0
    }

    fun setMinutes(value: Int) {
        minutes = value.coerceIn(MIN_MINUTES, MAX_MINUTES)
        cumulativeDegrees = ((minutes - MIN_MINUTES).toDouble() / LAP_MINUTES) * 360.0
        invalidate()
    }

    fun setCountdownMode(enabled: Boolean) {
        countdownMode = enabled
        invalidate()
    }

    fun setCountdownDisplay(text: String, progressFraction: Float) {
        countdownText = text
        countdownProgress = progressFraction.coerceIn(0f, 1f)
        invalidate()
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        cx = w / 2f
        cy = h / 2f
        val stroke = trackPaint.strokeWidth
        radius = (minOf(w, h) - stroke) / 2f
        rect.set(cx - radius, cy - radius, cx + radius, cy + radius)
        numberPaint.textSize = w * 0.19f
        unitPaint.textSize = w * 0.05f
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        canvas.drawArc(rect, 0f, 360f, false, trackPaint)

        if (countdownMode) {
            val sweep = 360f * countdownProgress
            canvas.save()
            canvas.rotate(-90f, cx, cy)
            canvas.drawArc(rect, 0f, sweep.coerceAtLeast(0.01f), false, progressPaint)
            canvas.restore()

            canvas.drawText(countdownText, cx, cy + numberPaint.textSize * 0.32f, numberPaint)
            canvas.drawText(
                "MIN : SEC", cx,
                cy + numberPaint.textSize * 0.32f + unitPaint.textSize * 2f, unitPaint
            )
        } else {
            val lapAngle = ((cumulativeDegrees % 360) + 360) % 360
            val fraction = lapAngle / 360.0
            val sweep = (360.0 * fraction).toFloat()

            canvas.save()
            canvas.rotate(-90f, cx, cy)
            canvas.drawArc(rect, 0f, sweep.coerceAtLeast(0.01f), false, progressPaint)
            canvas.restore()

            val rad = Math.toRadians(lapAngle - 90.0)
            val tx = cx + radius * cos(rad).toFloat()
            val ty = cy + radius * sin(rad).toFloat()
            canvas.drawCircle(tx, ty, 15f, thumbFillPaint)
            canvas.drawCircle(tx, ty, 15f, thumbStrokePaint)

            canvas.drawText(minutes.toString(), cx, cy + numberPaint.textSize * 0.32f, numberPaint)
            canvas.drawText(
                "MINUTES", cx,
                cy + numberPaint.textSize * 0.32f + unitPaint.textSize * 2f, unitPaint
            )
        }
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (countdownMode) return false
        when (event.action) {
            MotionEvent.ACTION_DOWN -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                lastAngle = angleFromTouch(event.x, event.y)
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                val angle = angleFromTouch(event.x, event.y)
                val prev = lastAngle
                if (prev != null) {
                    var delta = angle - prev
                    if (delta > 180) delta -= 360
                    if (delta < -180) delta += 360
                    val maxCum = ((MAX_MINUTES - MIN_MINUTES).toDouble() / LAP_MINUTES) * 360.0
                    cumulativeDegrees = (cumulativeDegrees + delta).coerceIn(0.0, maxCum)

                    val m = (MIN_MINUTES + (cumulativeDegrees / 360.0 * LAP_MINUTES).roundToInt())
                        .coerceIn(MIN_MINUTES, MAX_MINUTES)
                    if (m != minutes) {
                        minutes = m
                        onMinutesChanged?.invoke(minutes)
                        performHapticFeedback(
                            HapticFeedbackConstants.CLOCK_TICK,
                            HapticFeedbackConstants.FLAG_IGNORE_VIEW_SETTING
                        )
                    }
                    invalidate()
                }
                lastAngle = angle
                return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                parent?.requestDisallowInterceptTouchEvent(false)
                lastAngle = null
                return true
            }
        }
        return super.onTouchEvent(event)
    }

    private fun angleFromTouch(x: Float, y: Float): Double {
        val dx = (x - cx).toDouble()
        val dy = (y - cy).toDouble()
        val deg = atan2(dy, dx) * 180.0 / Math.PI
        return ((deg + 90 + 360) % 360)
    }
}
