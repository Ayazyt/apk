package com.example.sleeptimer

import android.service.notification.NotificationListenerService

/**
 * این سرویس هیچ اعلانی را نمی‌خواند یا ذخیره نمی‌کند؛ صرفاً وجودش (و فعال بودن
 * مجوز «دسترسی به اعلان‌ها») به اندروید اجازه می‌دهد از MediaSessionManager
 * برای گرفتن لیست برنامه‌های در حال پخش موسیقی و ارسال دستور Pause به آن‌ها
 * استفاده کنیم.
 */
class NotificationAccessService : NotificationListenerService()
