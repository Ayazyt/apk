package com.example.sleeptimer

import android.Manifest
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private lateinit var remainingText: TextView
    private lateinit var statusLabel: TextView
    private lateinit var minutesValueText: TextView
    private lateinit var decreaseButton: TextView
    private lateinit var increaseButton: TextView
    private lateinit var startButton: Button
    private lateinit var stopButton: Button
    private lateinit var timerRing: TimerRingView

    private var selectedMinutes = 30
    private var activeTotalMillis = 0L
    private val minMinutes = 5
    private val maxMinutes = 180
    private val step = 5

    private val tickReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            val remaining = intent?.getLongExtra(SleepTimerService.EXTRA_REMAINING_MS, 0) ?: 0
            if (remaining <= 0) {
                statusLabel.text = "پخش موسیقی متوقف شد"
                remainingText.text = "00:00"
                timerRing.setProgress(0f)
            } else {
                statusLabel.text = "در حال شمارش معکوس"
                val totalSeconds = remaining / 1000
                val m = totalSeconds / 60
                val s = totalSeconds % 60
                remainingText.text = String.format("%02d:%02d", m, s)
                if (activeTotalMillis > 0) {
                    timerRing.setProgress(remaining.toFloat() / activeTotalMillis.toFloat())
                }
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        remainingText = findViewById(R.id.remainingText)
        statusLabel = findViewById(R.id.statusLabel)
        minutesValueText = findViewById(R.id.minutesValueText)
        decreaseButton = findViewById(R.id.decreaseButton)
        increaseButton = findViewById(R.id.increaseButton)
        startButton = findViewById(R.id.startButton)
        stopButton = findViewById(R.id.stopButton)
        timerRing = findViewById(R.id.timerRing)

        timerRing.setProgress(1f)
        updateMinutesDisplay()

        decreaseButton.setOnClickListener {
            if (selectedMinutes > minMinutes) {
                selectedMinutes -= step
                updateMinutesDisplay()
            }
        }

        increaseButton.setOnClickListener {
            if (selectedMinutes < maxMinutes) {
                selectedMinutes += step
                updateMinutesDisplay()
            }
        }

        startButton.setOnClickListener {
            requestNotificationPermissionIfNeeded()
            activeTotalMillis = selectedMinutes * 60 * 1000L
            val intent = Intent(this, SleepTimerService::class.java).apply {
                putExtra(SleepTimerService.EXTRA_MINUTES, selectedMinutes)
            }
            ContextCompat.startForegroundService(this, intent)
            statusLabel.text = "در حال شمارش معکوس"
            timerRing.setProgress(1f)
        }

        stopButton.setOnClickListener {
            val intent = Intent(this, SleepTimerService::class.java).apply {
                action = SleepTimerService.ACTION_STOP
            }
            startService(intent)
            statusLabel.text = "آماده برای شروع"
            timerRing.setProgress(1f)
            updateMinutesDisplay()
        }
    }

    private fun updateMinutesDisplay() {
        minutesValueText.text = "$selectedMinutes دقیقه"
        remainingText.text = String.format("%02d:00", selectedMinutes)
    }

    private fun requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED
            ) {
                ActivityCompat.requestPermissions(
                    this,
                    arrayOf(Manifest.permission.POST_NOTIFICATIONS),
                    100
                )
            }
        }
    }

    override fun onStart() {
        super.onStart()
        val filter = IntentFilter(SleepTimerService.ACTION_TICK)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(tickReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            registerReceiver(tickReceiver, filter)
        }
    }

    override fun onStop() {
        super.onStop()
        unregisterReceiver(tickReceiver)
    }
}
