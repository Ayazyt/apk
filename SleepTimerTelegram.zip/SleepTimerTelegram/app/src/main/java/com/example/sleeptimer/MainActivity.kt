package com.example.sleeptimer

import android.Manifest
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private lateinit var statusLabel: TextView
    private lateinit var rotaryDial: RotaryDialView
    private lateinit var startButton: Button
    private lateinit var stopButton: Button
    private lateinit var pauseNowButton: TextView

    private var selectedMinutes = 30
    private var activeTotalMillis = 0L

    private val prefs by lazy { getSharedPreferences("hush_prefs", MODE_PRIVATE) }

    private val tickReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            val remaining = intent?.getLongExtra(SleepTimerService.EXTRA_REMAINING_MS, 0) ?: 0
            if (remaining <= 0) {
                statusLabel.text = "Music stopped"
                rotaryDial.setCountdownMode(false)
                rotaryDial.setMinutes(selectedMinutes)
            } else {
                statusLabel.text = "Counting down"
                val totalSeconds = remaining / 1000
                val m = totalSeconds / 60
                val s = totalSeconds % 60
                val text = String.format("%02d:%02d", m, s)
                val fraction = if (activeTotalMillis > 0) {
                    remaining.toFloat() / activeTotalMillis.toFloat()
                } else 1f
                rotaryDial.setCountdownMode(true)
                rotaryDial.setCountdownDisplay(text, fraction)
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        statusLabel = findViewById(R.id.statusLabel)
        rotaryDial = findViewById(R.id.rotaryDial)
        startButton = findViewById(R.id.startButton)
        stopButton = findViewById(R.id.stopButton)
        pauseNowButton = findViewById(R.id.pauseNowButton)

        // Restore the last selected duration from previous use.
        selectedMinutes = prefs.getInt("last_minutes", 30)
        rotaryDial.setMinutes(selectedMinutes)

        rotaryDial.onMinutesChanged = { value ->
            setSelectedMinutes(value)
        }

        findViewById<TextView>(R.id.preset15).setOnClickListener { applyPreset(15) }
        findViewById<TextView>(R.id.preset30).setOnClickListener { applyPreset(30) }
        findViewById<TextView>(R.id.preset45).setOnClickListener { applyPreset(45) }
        findViewById<TextView>(R.id.preset60).setOnClickListener { applyPreset(60) }
        findViewById<TextView>(R.id.preset90).setOnClickListener { applyPreset(90) }

        startButton.setOnClickListener {
            startTimerNow()
        }

        stopButton.setOnClickListener {
            val intent = Intent(this, SleepTimerService::class.java).apply {
                action = SleepTimerService.ACTION_STOP
            }
            startService(intent)
            statusLabel.text = "Ready to start"
            rotaryDial.setCountdownMode(false)
            rotaryDial.setMinutes(selectedMinutes)
        }

        pauseNowButton.setOnClickListener {
            if (isNotificationAccessGranted()) {
                val intent = Intent(this, SleepTimerService::class.java).apply {
                    action = SleepTimerService.ACTION_PAUSE_MUSIC
                }
                startService(intent)
                Toast.makeText(this, "Pause command sent to playing music", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(
                    this,
                    "Enable Notification Access for Hush to use this feature",
                    Toast.LENGTH_LONG
                ).show()
                startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
            }
        }

        // If the app was opened via a home-screen shortcut, start the timer immediately.
        handleAutostartIntent(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleAutostartIntent(intent)
    }

    private fun handleAutostartIntent(intent: Intent?) {
        val autoMinutes = intent?.getStringExtra("autostart_minutes")?.toIntOrNull()
        if (autoMinutes != null) {
            applyPreset(autoMinutes)
            startTimerNow()
        }
    }

    private fun applyPreset(minutes: Int) {
        setSelectedMinutes(minutes)
        rotaryDial.setMinutes(minutes)
    }

    private fun setSelectedMinutes(value: Int) {
        selectedMinutes = value
        prefs.edit().putInt("last_minutes", value).apply()
    }

    private fun startTimerNow() {
        requestNotificationPermissionIfNeeded()
        activeTotalMillis = selectedMinutes * 60 * 1000L
        val intent = Intent(this, SleepTimerService::class.java).apply {
            putExtra(SleepTimerService.EXTRA_MINUTES, selectedMinutes)
        }
        ContextCompat.startForegroundService(this, intent)
        statusLabel.text = "Counting down"
        rotaryDial.setCountdownMode(true)
        rotaryDial.setCountdownDisplay(String.format("%02d:00", selectedMinutes), 1f)
    }

    private fun isNotificationAccessGranted(): Boolean {
        return NotificationManagerCompat.getEnabledListenerPackages(this).contains(packageName)
    }

    private fun requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED
            ) {
                ActivityCompat.requestPermissions(
                    this,
                    arrayOf(Manifest.permission.POST_NOTIFICATIONS),
                    100
                )
            }
        }
    }

    override fun onStart() {
        super.onStart()
        val filter = IntentFilter(SleepTimerService.ACTION_TICK)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(tickReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            registerReceiver(tickReceiver, filter)
        }
    }

    override fun onStop() {
        super.onStop()
        unregisterReceiver(tickReceiver)
    }
}
