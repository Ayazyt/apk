package com.example.sleeptimer

import android.Manifest
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private lateinit var remainingText: TextView
    private lateinit var statusLabel: TextView
    private lateinit var minutePicker: MinutePickerView
    private lateinit var startButton: Button
    private lateinit var stopButton: Button
    private lateinit var pauseNowButton: TextView
    private lateinit var timerRing: TimerRingView

    private var selectedMinutes = 30
    private var activeTotalMillis = 0L

    private val tickReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            val remaining = intent?.getLongExtra(SleepTimerService.EXTRA_REMAINING_MS, 0) ?: 0
            if (remaining <= 0) {
                statusLabel.text = "پخش موسیقی متوقف شد"
                remainingText.text = "00:00"
                timerRing.setProgress(0f)
            } else {
                statusLabel.text = "در حال شمارش معکوس"
                val totalSeconds = remaining / 1000
                val m = totalSeconds / 60
                val s = totalSeconds % 60
                remainingText.text = String.format("%02d:%02d", m, s)
                if (activeTotalMillis > 0) {
                    timerRing.setProgress(remaining.toFloat() / activeTotalMillis.toFloat())
                }
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        remainingText = findViewById(R.id.remainingText)
        statusLabel = findViewById(R.id.statusLabel)
        minutePicker = findViewById(R.id.minutePicker)
        startButton = findViewById(R.id.startButton)
        stopButton = findViewById(R.id.stopButton)
        pauseNowButton = findViewById(R.id.pauseNowButton)
        timerRing = findViewById(R.id.timerRing)

        timerRing.setProgress(1f)
        minutePicker.setMinutes(selectedMinutes)
        updatePreviewTime(selectedMinutes)

        minutePicker.onValueChanged = { value ->
            selectedMinutes = value
            updatePreviewTime(value)
        }

        startButton.setOnClickListener {
            requestNotificationPermissionIfNeeded()
            activeTotalMillis = selectedMinutes * 60 * 1000L
            val intent = Intent(this, SleepTimerService::class.java).apply {
                putExtra(SleepTimerService.EXTRA_MINUTES, selectedMinutes)
            }
            ContextCompat.startForegroundService(this, intent)
            statusLabel.text = "در حال شمارش معکوس"
            timerRing.setProgress(1f)
        }

        stopButton.setOnClickListener {
            val intent = Intent(this, SleepTimerService::class.java).apply {
                action = SleepTimerService.ACTION_STOP
            }
            startService(intent)
            statusLabel.text = "آماده برای شروع"
            timerRing.setProgress(1f)
            updatePreviewTime(selectedMinutes)
        }

        pauseNowButton.setOnClickListener {
            if (isNotificationAccessGranted()) {
                val intent = Intent(this, SleepTimerService::class.java).apply {
                    action = SleepTimerService.ACTION_PAUSE_MUSIC
                }
                startService(intent)
                Toast.makeText(this, "دستور توقف به موزیک در حال پخش ارسال شد", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(
                    this,
                    "برای این قابلیت، دسترسی «اعلان‌ها» را برای SM Mute فعال کنید",
                    Toast.LENGTH_LONG
                ).show()
                startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
            }
        }
    }

    private fun isNotificationAccessGranted(): Boolean {
        return NotificationManagerCompat.getEnabledListenerPackages(this).contains(packageName)
    }

    private fun updatePreviewTime(minutes: Int) {
        remainingText.text = String.format("%02d:00", minutes)
    }

    private fun requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED
            ) {
                ActivityCompat.requestPermissions(
                    this,
                    arrayOf(Manifest.permission.POST_NOTIFICATIONS),
                    100
                )
            }
        }
    }

    override fun onStart() {
        super.onStart()
        val filter = IntentFilter(SleepTimerService.ACTION_TICK)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(tickReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            registerReceiver(tickReceiver, filter)
        }
    }

    override fun onStop() {
        super.onStop()
        unregisterReceiver(tickReceiver)
    }
}
