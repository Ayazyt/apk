package com.example.sleeptimer

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.animation.AccelerateDecelerateInterpolator
import androidx.appcompat.app.AppCompatActivity

class SplashActivity : AppCompatActivity() {

    private val handler = Handler(Looper.getMainLooper())
    private var navigated = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash)

        val logo = findViewById<android.widget.ImageView>(R.id.logoImage)
        val glow = findViewById<android.view.View>(R.id.glowView)
        val appName = findViewById<android.widget.TextView>(R.id.appNameText)
        val tagline = findViewById<android.widget.TextView>(R.id.appTaglineText)
        val divider = findViewById<android.view.View>(R.id.dividerLine)
        val credit = findViewById<android.widget.TextView>(R.id.creditText)
        val studio = findViewById<android.widget.TextView>(R.id.studioText)

        // انیمیشن سبک ورود (Fade + Scale) بدون بار اضافی روی CPU
        logo.scaleX = 0.6f
        logo.scaleY = 0.6f
        logo.alpha = 0f
        glow.alpha = 0f
        listOf(appName, tagline, divider, credit, studio).forEach { it.alpha = 0f }

        glow.animate().alpha(1f).setDuration(500).start()
        logo.animate()
            .alpha(1f)
            .scaleX(1f)
            .scaleY(1f)
            .setDuration(550)
            .setInterpolator(AccelerateDecelerateInterpolator())
            .start()

        appName.animate().alpha(1f).setStartDelay(300).setDuration(400).start()
        tagline.animate().alpha(1f).setStartDelay(420).setDuration(400).start()
        divider.animate().alpha(1f).setStartDelay(600).setDuration(400).start()
        credit.animate().alpha(1f).setStartDelay(700).setDuration(400).start()
        studio.animate().alpha(1f).setStartDelay(820).setDuration(400).start()

        handler.postDelayed({
            goToMain()
        }, 3000)
    }

    private fun goToMain() {
        if (navigated || isFinishing) return
        navigated = true
        startActivity(Intent(this, MainActivity::class.java))
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
        finish()
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }
}
