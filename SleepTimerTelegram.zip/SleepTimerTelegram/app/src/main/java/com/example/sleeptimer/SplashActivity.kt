package com.example.sleeptimer

import android.animation.AnimatorSet
import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.content.Intent
import android.graphics.LinearGradient
import android.graphics.Shader
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.view.animation.AccelerateDecelerateInterpolator
import android.view.animation.LinearInterpolator
import android.widget.FrameLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import kotlin.random.Random

class SplashActivity : AppCompatActivity() {

    private val handler = Handler(Looper.getMainLooper())
    private var navigated = false

    // مدت زمان صفحه‌ی لودینگ (میلی‌ثانیه)
    private val splashDuration = 6000L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash)

        val glow = findViewById<View>(R.id.glowView)
        val ringOuter = findViewById<View>(R.id.breathRingOuter)
        val ringInner = findViewById<View>(R.id.breathRingInner)
        val logoBadge = findViewById<View>(R.id.logoBadge)
        val appName = findViewById<TextView>(R.id.appNameText)
        val tagline = findViewById<TextView>(R.id.appTaglineText)
        val loaderFill = findViewById<View>(R.id.loaderFill)
        val loaderTrack = findViewById<View>(R.id.loaderTrack)
        val creditPlaque = findViewById<View>(R.id.creditPlaque)
        val studioText = findViewById<TextView>(R.id.studioText)
        val starsLayer = findViewById<FrameLayout>(R.id.starsLayer)

        // متن گرادیانی برای "66xSTORM"
        studioText.post {
            val width = studioText.paint.measureText(studioText.text.toString())
            val shader = LinearGradient(
                0f, 0f, width, 0f,
                intArrayOf(0xFF9C90FF.toInt(), 0xFF4FD8C4.toInt()),
                null, Shader.TileMode.CLAMP
            )
            studioText.paint.shader = shader
            studioText.invalidate()
        }

        // ورود اولیه (fade + scale)
        logoBadge.scaleX = 0.6f; logoBadge.scaleY = 0.6f; logoBadge.alpha = 0f
        glow.alpha = 0f
        listOf(appName, tagline, loaderTrack, creditPlaque).forEach { it.alpha = 0f }

        glow.animate().alpha(1f).setDuration(600).start()
        logoBadge.animate().alpha(1f).scaleX(1f).scaleY(1f)
            .setDuration(600).setInterpolator(AccelerateDecelerateInterpolator()).start()
        appName.animate().alpha(1f).setStartDelay(320).setDuration(450).start()
        tagline.animate().alpha(1f).setStartDelay(440).setDuration(450).start()
        loaderTrack.animate().alpha(1f).setStartDelay(560).setDuration(450).start()
        creditPlaque.animate().alpha(1f).setStartDelay(680).setDuration(450).start()

        // انیمیشن تنفسِ پیوسته دور لوگو (شبیه‌سازی ریتم نفس هنگام خواب)
        startBreathing(ringOuter, 0)
        startBreathing(ringInner, 150)
        startBreathing(glow, 0)

        // ستاره‌های چشمک‌زن
        scatterStars(starsLayer, 16)

        // نوار پیشرفت واقعی که دقیقاً هم‌زمان با مدت لودینگ پر می‌شود
        ValueAnimator.ofInt(0, 1000).apply {
            duration = splashDuration
            interpolator = LinearInterpolator()
            addUpdateListener { anim ->
                val fraction = anim.animatedValue as Int
                val trackWidth = loaderTrack.width
                if (trackWidth > 0) {
                    loaderFill.layoutParams.width = (trackWidth * fraction / 1000f).toInt()
                    loaderFill.requestLayout()
                }
            }
            start()
        }

        handler.postDelayed({ goToMain() }, splashDuration)
    }

    private fun startBreathing(view: View, delay: Long) {
        val scaleX = ObjectAnimator.ofFloat(view, "scaleX", 0.92f, 1.08f)
        val scaleY = ObjectAnimator.ofFloat(view, "scaleY", 0.92f, 1.08f)
        val alpha = ObjectAnimator.ofFloat(view, "alpha", 0.4f, 0.95f)
        val set = AnimatorSet()
        set.playTogether(scaleX, scaleY, alpha)
        set.duration = 2000
        set.startDelay = delay
        set.interpolator = AccelerateDecelerateInterpolator()
        set.addListener(object : android.animation.AnimatorListenerAdapter() {
            override fun onAnimationEnd(animation: android.animation.Animator) {
                if (!isFinishing) {
                    val reverse = AnimatorSet()
                    reverse.playTogether(
                        ObjectAnimator.ofFloat(view, "scaleX", 1.08f, 0.92f),
                        ObjectAnimator.ofFloat(view, "scaleY", 1.08f, 0.92f),
                        ObjectAnimator.ofFloat(view, "alpha", 0.95f, 0.4f)
                    )
                    reverse.duration = 2000
                    reverse.interpolator = AccelerateDecelerateInterpolator()
                    reverse.addListener(object : android.animation.AnimatorListenerAdapter() {
                        override fun onAnimationEnd(animation: android.animation.Animator) {
                            if (!isFinishing) startBreathing(view, 0)
                        }
                    })
                    reverse.start()
                }
            }
        })
        set.start()
    }

    private fun scatterStars(container: FrameLayout, count: Int) {
        container.post {
            val w = container.width
            val h = (container.height * 0.55f).toInt()
            if (w <= 0) return@post
            repeat(count) {
                val star = View(this).apply {
                    setBackgroundColor(0xFFFFFFFF.toInt())
                    alpha = 0.2f
                }
                val size = Random.nextInt(3, 6)
                val params = FrameLayout.LayoutParams(size, size)
                params.leftMargin = Random.nextInt(0, w.coerceAtLeast(1))
                params.topMargin = Random.nextInt(0, h.coerceAtLeast(1))
                container.addView(star, params)

                val twinkle = ObjectAnimator.ofFloat(star, "alpha", 0.15f, 0.9f, 0.15f)
                twinkle.duration = Random.nextLong(1800, 3200)
                twinkle.startDelay = Random.nextLong(0, 2500)
                twinkle.repeatCount = ValueAnimator.INFINITE
                twinkle.start()
            }
        }
    }

    private fun goToMain() {
        if (navigated || isFinishing) return
        navigated = true
        startActivity(Intent(this, MainActivity::class.java))
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
        finish()
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }
}
