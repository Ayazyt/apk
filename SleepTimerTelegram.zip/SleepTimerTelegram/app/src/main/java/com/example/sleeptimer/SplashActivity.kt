package com.example.sleeptimer

import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.view.animation.AccelerateDecelerateInterpolator
import android.view.animation.LinearInterpolator
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class SplashActivity : AppCompatActivity() {

    private val handler = Handler(Looper.getMainLooper())
    private var navigated = false
    private val splashDuration = 6000L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash)

        val spinnerArc = findViewById<ImageView>(R.id.spinnerArc)
        val logoBadge = findViewById<View>(R.id.logoBadge)
        val appName = findViewById<TextView>(R.id.appNameText)
        val tagline = findViewById<TextView>(R.id.appTaglineText)
        val loaderFill = findViewById<View>(R.id.loaderFill)
        val loaderTrack = findViewById<View>(R.id.loaderTrack)
        val creditPlaque = findViewById<View>(R.id.creditPlaque)

        // ورود اولیه
        logoBadge.scaleX = 0.7f; logoBadge.scaleY = 0.7f; logoBadge.alpha = 0f
        listOf(appName, tagline, loaderTrack, creditPlaque).forEach { it.alpha = 0f }

        logoBadge.animate().alpha(1f).scaleX(1f).scaleY(1f)
            .setDuration(500).setInterpolator(AccelerateDecelerateInterpolator()).start()
        appName.animate().alpha(1f).setStartDelay(250).setDuration(400).start()
        tagline.animate().alpha(1f).setStartDelay(370).setDuration(400).start()
        loaderTrack.animate().alpha(1f).setStartDelay(480).setDuration(400).start()
        creditPlaque.animate().alpha(1f).setStartDelay(600).setDuration(400).start()

        // اسپینر چرخان پیوسته دور بج لوگو
        ObjectAnimator.ofFloat(spinnerArc, "rotation", 0f, 360f).apply {
            duration = 1400
            repeatCount = ValueAnimator.INFINITE
            interpolator = LinearInterpolator()
            start()
        }

        // نوار پیشرفت واقعی هم‌زمان با مدت لودینگ
        ValueAnimator.ofInt(0, 1000).apply {
            duration = splashDuration
            interpolator = LinearInterpolator()
            addUpdateListener { anim ->
                val fraction = anim.animatedValue as Int
                val trackWidth = loaderTrack.width
                if (trackWidth > 0) {
                    loaderFill.layoutParams.width = (trackWidth * fraction / 1000f).toInt()
                    loaderFill.requestLayout()
                }
            }
            start()
        }

        handler.postDelayed({ goToMain() }, splashDuration)
    }

    private fun goToMain() {
        if (navigated || isFinishing) return
        navigated = true
        startActivity(Intent(this, MainActivity::class.java))
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
        finish()
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }
}
