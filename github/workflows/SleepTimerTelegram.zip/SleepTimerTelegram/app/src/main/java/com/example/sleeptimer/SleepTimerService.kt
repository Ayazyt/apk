package com.example.sleeptimer

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.os.Build
import android.os.CountDownTimer
import android.os.IBinder
import androidx.core.app.NotificationCompat

/**
 * این سرویس یک شمارش معکوس اجرا می‌کند.
 * وقتی زمان تمام شود، با گرفتن Audio Focus به صورت انحصاری،
 * سیستم اندروید به تمام برنامه‌های در حال پخش صدا (از جمله تلگرام)
 * دستور توقف/مکث پخش را می‌دهد. این روش استاندارد و مستقل از اپلیکیشن است
 * و نیازی به دسترسی خاص به تلگرام ندارد.
 */
class SleepTimerService : Service() {

    private var countDownTimer: CountDownTimer? = null
    private lateinit var audioManager: AudioManager

    companion object {
        const val CHANNEL_ID = "sleep_timer_channel"
        const val NOTIFICATION_ID = 1
        const val EXTRA_MINUTES = "extra_minutes"
        const val ACTION_STOP = "action_stop_timer"
        const val ACTION_TICK = "com.example.sleeptimer.TICK"
        const val EXTRA_REMAINING_MS = "extra_remaining_ms"
    }

    override fun onCreate() {
        super.onCreate()
        audioManager = getSystemService(AUDIO_SERVICE) as AudioManager
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopTimerAndSelf()
            return START_NOT_STICKY
        }

        val minutes = intent?.getIntExtra(EXTRA_MINUTES, 30) ?: 30
        val millis = minutes * 60 * 1000L

        startForeground(NOTIFICATION_ID, buildNotification(formatTime(millis)))
        startCountdown(millis)

        return START_STICKY
    }

    private fun startCountdown(millis: Long) {
        countDownTimer?.cancel()
        countDownTimer = object : CountDownTimer(millis, 1000) {
            override fun onTick(millisUntilFinished: Long) {
                updateNotification(formatTime(millisUntilFinished))
                sendTick(millisUntilFinished)
            }

            override fun onFinish() {
                pauseAllMediaPlayback()
                sendTick(0)
                stopSelf()
            }
        }.start()
    }

    /**
     * قلب ماجرا: با گرفتن فوکوس صوتی به صورت "GAIN"، اندروید به هر برنامه‌ای
     * که در حال پخش صداست (تلگرام، اسپاتیفای، یوتیوب و ...) دستور توقف موقت
     * یا کامل پخش را می‌دهد.
     */
    private fun pauseAllMediaPlayback() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val attrs = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                .build()

            val focusRequest = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
                .setAudioAttributes(attrs)
                .setOnAudioFocusChangeListener { }
                .build()

            audioManager.requestAudioFocus(focusRequest)

            // کمی بعد فوکوس را رها می‌کنیم؛ خود عمل گرفتن فوکوس باعث
            // ارسال سیگنال توقف پخش به برنامه‌ی دیگر شده است.
            audioManager.abandonAudioFocusRequest(focusRequest)
        } else {
            @Suppress("DEPRECATION")
            audioManager.requestAudioFocus(
                null,
                AudioManager.STREAM_MUSIC,
                AudioManager.AUDIOFOCUS_GAIN
            )
        }
    }

    private fun stopTimerAndSelf() {
        countDownTimer?.cancel()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun sendTick(remainingMs: Long) {
        val tickIntent = Intent(ACTION_TICK).apply {
            putExtra(EXTRA_REMAINING_MS, remainingMs)
            setPackage(packageName)
        }
        sendBroadcast(tickIntent)
    }

    private fun formatTime(millis: Long): String {
        val totalSeconds = millis / 1000
        val m = totalSeconds / 60
        val s = totalSeconds % 60
        return String.format("%02d:%02d", m, s)
    }

    private fun buildNotification(timeText: String): android.app.Notification {
        val stopIntent = Intent(this, SleepTimerService::class.java).apply {
            action = ACTION_STOP
        }
        val stopPendingIntent = PendingIntent.getService(
            this, 0, stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("تایمر خواب فعال است")
            .setContentText("زمان باقی‌مانده: $timeText")
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setOngoing(true)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "توقف", stopPendingIntent)
            .build()
    }

    private fun updateNotification(timeText: String) {
        val manager = getSystemService(NotificationManager::class.java)
        manager.notify(NOTIFICATION_ID, buildNotification(timeText))
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Sleep Timer",
                NotificationManager.IMPORTANCE_LOW
            )
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
    }

    override fun onDestroy() {
        countDownTimer?.cancel()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
