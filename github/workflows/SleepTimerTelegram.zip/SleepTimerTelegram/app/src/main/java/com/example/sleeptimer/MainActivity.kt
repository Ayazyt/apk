package com.example.sleeptimer

import android.Manifest
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.Button
import android.widget.NumberPicker
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private lateinit var remainingText: TextView
    private lateinit var minutesPicker: NumberPicker
    private lateinit var startButton: Button
    private lateinit var stopButton: Button

    private val tickReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            val remaining = intent?.getLongExtra(SleepTimerService.EXTRA_REMAINING_MS, 0) ?: 0
            if (remaining <= 0) {
                remainingText.text = "پخش متوقف شد"
            } else {
                val totalSeconds = remaining / 1000
                val m = totalSeconds / 60
                val s = totalSeconds % 60
                remainingText.text = String.format("%02d:%02d", m, s)
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        remainingText = findViewById(R.id.remainingText)
        minutesPicker = findViewById(R.id.minutesPicker)
        startButton = findViewById(R.id.startButton)
        stopButton = findViewById(R.id.stopButton)

        minutesPicker.minValue = 1
        minutesPicker.maxValue = 180
        minutesPicker.value = 30

        startButton.setOnClickListener {
            requestNotificationPermissionIfNeeded()
            val intent = Intent(this, SleepTimerService::class.java).apply {
                putExtra(SleepTimerService.EXTRA_MINUTES, minutesPicker.value)
            }
            ContextCompat.startForegroundService(this, intent)
        }

        stopButton.setOnClickListener {
            val intent = Intent(this, SleepTimerService::class.java).apply {
                action = SleepTimerService.ACTION_STOP
            }
            startService(intent)
            remainingText.text = "--:--"
        }
    }

    private fun requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED
            ) {
                ActivityCompat.requestPermissions(
                    this,
                    arrayOf(Manifest.permission.POST_NOTIFICATIONS),
                    100
                )
            }
        }
    }

    override fun onStart() {
        super.onStart()
        val filter = IntentFilter(SleepTimerService.ACTION_TICK)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(tickReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            registerReceiver(tickReceiver, filter)
        }
    }

    override fun onStop() {
        super.onStop()
        unregisterReceiver(tickReceiver)
    }
}
